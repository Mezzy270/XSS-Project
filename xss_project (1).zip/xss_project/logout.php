<?php
require "config.php";
require "functions.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();   // logout only works from our own button

    if (isset($_SESSION["username"])) {
        log_action($conn, $_SESSION["username"], "Logged out");
    }

    $_SESSION = [];
    session_destroy();
    session_start();
    session_regenerate_id(true);
    set_flash("success", "You logged out safely.");
}

header("Location: login.php");
exit;
