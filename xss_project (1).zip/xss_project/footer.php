</main>
<footer class="foot">SafeBoard demo: built to learn about XSS and safe logins.</footer>
</body>
</html>
