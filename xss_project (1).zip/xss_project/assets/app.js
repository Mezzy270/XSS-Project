document.addEventListener('DOMContentLoaded', function () {

  // Live password rules + strength meter (register page)
  var pw = document.getElementById('password');
  var bar = document.getElementById('strength');
  var label = document.getElementById('strengthLabel');

  if (pw && bar) {
    var rules = {
      length: function (v) { return v.length >= 8; },
      upper:  function (v) { return /[A-Z]/.test(v); },
      lower:  function (v) { return /[a-z]/.test(v); },
      number: function (v) { return /[0-9]/.test(v); }
    };
    var names = ['Too weak', 'Weak', 'Okay', 'Good', 'Strong', 'Very strong'];

    pw.addEventListener('input', function () {
      var v = pw.value, score = 0;
      Object.keys(rules).forEach(function (k) {
        var ok = rules[k](v);
        var li = document.querySelector('[data-rule="' + k + '"]');
        if (li) { li.classList.toggle('ok', ok); }
        if (ok) { score++; }
      });
      if (v.length >= 12) { score++; }          // bonus for long passwords
      bar.setAttribute('data-level', score);
      if (label) { label.textContent = names[score]; }
    });
  }

  // Show / hide password buttons
  document.querySelectorAll('[data-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-toggle'));
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
    });
  });

  // Character counter for the message box
  var msg = document.getElementById('message');
  var count = document.getElementById('count');
  if (msg && count) {
    msg.addEventListener('input', function () { count.textContent = msg.value.length; });
  }
});
