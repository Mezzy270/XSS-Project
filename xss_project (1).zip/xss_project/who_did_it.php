<?php
// PART 3: SECURE VERSION
require "config.php";
require "functions.php";
secure_headers();

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}

$me = $_SESSION["username"];
$error = "";

// Mood list: only these values are allowed (whitelist)
$moods = [
    "happy"    => "😊 Happy",
    "focused"  => "🎯 Focused",
    "stressed" => "😵 Stressed",
    "sleepy"   => "😴 Sleepy",
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $do = $_POST["do"] ?? "";

    if ($do === "post") {
        $raw  = $_POST["message"] ?? "";
        $mood = $_POST["mood"] ?? "happy";
        if (!array_key_exists($mood, $moods)) {
            $mood = "happy";
        }

        // Spot an attack, then log it
        if (looks_like_xss($raw)) {
            log_action($conn, $me, "XSS attempt blocked");
        }

        $message = clean_input($raw);   // remove tags

        if ($message === "") {
            $error = "Message is empty after cleaning. Tags are not allowed.";
        } elseif (mb_strlen($message) > 300) {
            $error = "Message is too long (300 characters max).";
        } else {
            $stmt = $conn->prepare("INSERT INTO messages (username, message, mood) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $me, $message, $mood);
            $stmt->execute();
            log_action($conn, $me, "Posted a message");
        }

    } elseif ($do === "delete") {
        $id = (int)($_POST["id"] ?? 0);
        // Users can only delete their own messages
        $stmt = $conn->prepare("DELETE FROM messages WHERE id = ? AND username = ?");
        $stmt->bind_param("is", $id, $me);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            log_action($conn, $me, "Deleted a message");
        }
    }
}

$messages = $conn->query("SELECT * FROM messages ORDER BY id DESC LIMIT 30");
$audit    = $conn->query("SELECT username, action, ip, created_at FROM audit_log ORDER BY id DESC LIMIT 8");
$blocked  = $conn->query("SELECT COUNT(*) AS c FROM audit_log WHERE action = 'XSS attempt blocked'")->fetch_assoc()["c"];

$title = "Who Did It";
require "header.php";
?>
<section class="card shield">
    <div>
        <h2>🛡️ XSS Shield</h2>
        <p class="muted">Attacks caught and logged so far</p>
    </div>
    <div class="bignum"><?php echo (int)$blocked; ?></div>
</section>

<section class="card">
    <h2>Post a message</h2>

    <?php if ($error !== ""): ?>
        <div class="alert error"><?php echo e($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="do" value="post">

        <label for="message">What did you do today?</label>
        <textarea id="message" name="message" rows="3" maxlength="300" required></textarea>
        <p class="muted"><span id="count">0</span> / 300</p>

        <label for="mood">Mood</label>
        <select id="mood" name="mood">
            <?php foreach ($moods as $key => $label): ?>
                <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
            <?php endforeach; ?>
        </select>

        <button class="btn" type="submit">Post</button>
    </form>
</section>

<section class="card">
    <h2>Who did it</h2>
    <?php while ($row = $messages->fetch_assoc()): ?>
        <article class="post">
            <div class="postHead">
                <strong><?php echo e($row["username"]); ?></strong>
                <span class="badge"><?php echo e($moods[$row["mood"]] ?? $moods["happy"]); ?></span>
                <span class="muted"><?php echo e($row["created_at"]); ?></span>
            </div>
            <p><?php echo e($row["message"]); ?></p>
            <?php if ($row["username"] === $me): ?>
                <form method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="do" value="delete">
                    <input type="hidden" name="id" value="<?php echo (int)$row["id"]; ?>">
                    <button class="btn small ghost" type="submit">Delete</button>
                </form>
            <?php endif; ?>
        </article>
    <?php endwhile; ?>
</section>

<section class="card">
    <h2>🕵️ Activity log</h2>
    <div class="scroll">
        <table>
            <tr><th>User</th><th>Action</th><th>IP</th><th>Time</th></tr>
            <?php while ($a = $audit->fetch_assoc()): ?>
                <tr>
                    <td><?php echo e($a["username"]); ?></td>
                    <td><?php echo e($a["action"]); ?></td>
                    <td><?php echo e($a["ip"]); ?></td>
                    <td><?php echo e($a["created_at"]); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</section>
<?php require "footer.php"; ?>
