# SafeBoard: XSS demo with safe login

## Setup
1. Put the folder in htdocs (XAMPP) or www (WAMP).
2. Import database.sql in phpMyAdmin.
3. Open http://localhost/xss_project/register.php

## Pages
- register.php, login.php, logout.php
- who_did_it_vulnerable.php  (Part 2: attack demo)
- who_did_it.php             (Part 3: protected version)

## Protection layers against XSS
1. Escape output with htmlspecialchars (the e() function)
2. Clean input with strip_tags (clean_input)
3. Spot and log attack attempts (looks_like_xss)
4. Content Security Policy header, scripts only from our own site
5. HttpOnly + SameSite session cookie

## Extra security
- Password rules: 8+ chars, uppercase, lowercase, number
- Live strength meter and rule checklist
- Passwords hashed with password_hash
- Prepared statements (stops SQL injection)
- CSRF tokens on every form
- Lockout for 5 minutes after 5 wrong passwords
- Auto logout after 15 minutes idle
- Honeypot field against bots
- Username whitelist (letters, numbers, underscore)
- Activity log shows who did what, with IP and time
