<?php
// PART 2: VULNERABLE VERSION. For the attack demo only.
// No escaping, no cleaning, no security headers.
require "config.php";

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $message  = $_POST["message"];          // not cleaned
    $username = $_SESSION["username"];
    $mood     = "happy";

    $stmt = $conn->prepare("INSERT INTO messages (username, message, mood) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $message, $mood);
    $stmt->execute();
}

$result = $conn->query("SELECT * FROM messages ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Who Did It (VULNERABLE)</title>
</head>
<body style="font-family:sans-serif;padding:16px">
    <h2>Welcome, <?php echo $_SESSION["username"]; ?></h2>
    <p style="color:#b00"><strong>This page is vulnerable on purpose.</strong>
       <a href="who_did_it.php">Go to secure version</a></p>

    <form method="POST">
        <p>Write a message:<br><textarea name="message" rows="3" cols="40"></textarea></p>
        <button type="submit">Post</button>
    </form>

    <h3>Who did it</h3>
    <table border="1" cellpadding="6">
        <tr><th>User</th><th>Message</th><th>Time</th></tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row["username"]; ?></td>
            <td><?php echo $row["message"]; ?></td>
            <td><?php echo $row["created_at"]; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
