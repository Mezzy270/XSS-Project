<?php
// ---------- Session hardening ----------
ini_set('session.cookie_httponly', 1);      // JavaScript cannot read the cookie
ini_set('session.use_strict_mode', 1);      // server rejects made-up session ids
ini_set('session.cookie_samesite', 'Strict'); // cookie is not sent from other sites
if (!empty($_SERVER['HTTPS'])) {
    ini_set('session.cookie_secure', 1);
}
session_start();

// ---------- Settings ----------
define('MAX_ATTEMPTS', 5);       // wrong passwords before lockout
define('LOCK_MINUTES', 5);       // how long the lockout lasts
define('IDLE_TIMEOUT', 900);     // auto logout after 15 minutes of no activity

// ---------- Auto logout when idle ----------
if (isset($_SESSION['last_active']) && (time() - $_SESSION['last_active']) > IDLE_TIMEOUT) {
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['flash'] = ['type' => 'warn', 'text' => 'You were logged out because you were inactive.'];
}
$_SESSION['last_active'] = time();

// ---------- Database ----------
$conn = new mysqli("localhost", "root", "", "xss_demo");
if ($conn->connect_error) {
    die("Database connection failed.");
}
$conn->set_charset("utf8mb4");
