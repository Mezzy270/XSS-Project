<?php
require "config.php";
require "functions.php";
secure_headers();

if (isset($_SESSION["username"])) {
    header("Location: who_did_it.php");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();

    $username = clean_input($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $conn->prepare(
        "SELECT id, username, password, failed_attempts,
                (locked_until IS NOT NULL AND locked_until > NOW()) AS is_locked,
                TIMESTAMPDIFF(SECOND, NOW(), locked_until) AS secs_left
         FROM users WHERE username = ?"
    );
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && $user["is_locked"]) {
        // Account is locked after too many wrong tries
        $mins = max(1, (int)ceil($user["secs_left"] / 60));
        $error = "Too many wrong tries. Try again in about $mins minute(s).";
        log_action($conn, $user["username"], "Login blocked (account locked)");

    } elseif ($user && password_verify($password, $user["password"])) {
        // Success
        session_regenerate_id(true);   // new session id stops session fixation
        unset($_SESSION["csrf"]);      // new CSRF token for the new session
        $_SESSION["user_id"]  = $user["id"];
        $_SESSION["username"] = $user["username"];

        $stmt = $conn->prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?");
        $stmt->bind_param("i", $user["id"]);
        $stmt->execute();

        log_action($conn, $user["username"], "Logged in");
        header("Location: who_did_it.php");
        exit;

    } else {
        // Same message for unknown user and wrong password, so attackers learn nothing
        if (!$user) {
            password_verify($password, password_hash("dummy", PASSWORD_DEFAULT)); // keeps timing similar
        } else {
            $attempts = $user["failed_attempts"] + 1;
            if ($attempts >= MAX_ATTEMPTS) {
                $mins = LOCK_MINUTES;
                $stmt = $conn->prepare("UPDATE users SET failed_attempts = 0, locked_until = DATE_ADD(NOW(), INTERVAL $mins MINUTE) WHERE id = ?");
                $stmt->bind_param("i", $user["id"]);
                $stmt->execute();
                log_action($conn, $user["username"], "Account locked (too many wrong passwords)");
            } else {
                $stmt = $conn->prepare("UPDATE users SET failed_attempts = ? WHERE id = ?");
                $stmt->bind_param("ii", $attempts, $user["id"]);
                $stmt->execute();
                log_action($conn, $user["username"], "Wrong password");
            }
        }
        $error = "Wrong username or password.";
    }
}

$title = "Login";
require "header.php";
?>
<section class="card narrow">
    <h2>Welcome back</h2>

    <?php if ($error !== ""): ?>
        <div class="alert error"><?php echo e($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <?php echo csrf_field(); ?>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password</label>
        <div class="pwrow">
            <input type="password" id="password" name="password" required>
            <button type="button" class="btn small ghost" data-toggle="password">Show</button>
        </div>

        <button class="btn" type="submit">Login</button>
    </form>
    <p class="muted">No account yet? <a href="register.php">Register</a></p>
</section>
<?php require "footer.php"; ?>
