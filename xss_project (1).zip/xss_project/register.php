<?php
require "config.php";
require "functions.php";
secure_headers();

$errors = [];
$username = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();

    // Honeypot: real people never see this box, bots fill it
    if (!empty($_POST["website"])) {
        die("Request blocked.");
    }

    $username = clean_input($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm  = $_POST["confirm"] ?? "";

    // Only letters, numbers and underscore. This alone blocks script tags in names.
    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $username)) {
        $errors[] = "Username must be 3 to 20 characters: letters, numbers or underscore.";
    }

    $errors = array_merge($errors, password_problems($password, $username));

    if ($password !== $confirm) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors[] = "That username is taken.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hash);
            $stmt->execute();
            log_action($conn, $username, "Account created");
            set_flash("success", "Account created. You can log in now.");
            header("Location: login.php");
            exit;
        }
    }
}

$title = "Register";
require "header.php";
?>
<section class="card narrow">
    <h2>Create account</h2>

    <?php foreach ($errors as $err): ?>
        <div class="alert error"><?php echo e($err); ?></div>
    <?php endforeach; ?>

    <form method="POST" autocomplete="off">
        <?php echo csrf_field(); ?>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="<?php echo e($username); ?>" maxlength="20" required>

        <label for="password">Password</label>
        <div class="pwrow">
            <input type="password" id="password" name="password" required>
            <button type="button" class="btn small ghost" data-toggle="password">Show</button>
        </div>

        <div class="meter"><div id="strength" data-level="0"></div></div>
        <p class="muted">Strength: <strong id="strengthLabel">Too weak</strong></p>

        <ul class="rules">
            <li data-rule="length">At least 8 characters</li>
            <li data-rule="upper">One uppercase letter (A-Z)</li>
            <li data-rule="lower">One lowercase letter (a-z)</li>
            <li data-rule="number">One number (0-9)</li>
        </ul>

        <label for="confirm">Confirm password</label>
        <input type="password" id="confirm" name="confirm" required>

        <!-- Honeypot field, hidden with CSS -->
        <div class="hp"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>

        <button class="btn" type="submit">Register</button>
    </form>
    <p class="muted">Already have an account? <a href="login.php">Login</a></p>
</section>
<?php require "footer.php"; ?>
