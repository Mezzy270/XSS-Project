<?php $flash = get_flash(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? "SafeBoard"); ?></title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/app.js" defer></script>
</head>
<body>
<header class="topbar">
    <div class="brand">🛡️ SafeBoard</div>
    <nav>
        <?php if (isset($_SESSION['username'])): ?>
            <span class="who">👤 <?php echo e($_SESSION['username']); ?></span>
            <form method="POST" action="logout.php" class="inline">
                <?php echo csrf_field(); ?>
                <button class="btn small ghost" type="submit">Logout</button>
            </form>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main class="wrap">
<?php if ($flash): ?>
    <div class="alert <?php echo e($flash['type']); ?>"><?php echo e($flash['text']); ?></div>
<?php endif; ?>
