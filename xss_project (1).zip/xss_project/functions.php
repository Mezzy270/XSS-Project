<?php
/* =========================================================
   LAYER 1: Escape output. Browser shows code as plain text.
   ========================================================= */
function e($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}

/* =========================================================
   LAYER 2: Clean input. Remove spaces and HTML tags.
   ========================================================= */
function clean_input($text) {
    return trim(strip_tags((string)$text));
}

/* =========================================================
   LAYER 3: Spot suspicious input so we can log it.
   ========================================================= */
function looks_like_xss($text) {
    return (bool) preg_match('/<\s*\/?\s*[a-z!]|javascript\s*:|on[a-z]+\s*=|&#x?[0-9a-f]+;/i', $text);
}

/* =========================================================
   LAYER 4: Security headers. Browser only runs our own code.
   ========================================================= */
function secure_headers() {
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; form-action 'self'; base-uri 'self'");
    header("X-Content-Type-Options: nosniff");
    header("X-Frame-Options: DENY");
    header("Referrer-Policy: no-referrer");
}

/* ---------- CSRF token: stops fake forms from other sites ---------- */
function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
function verify_csrf() {
    if (!isset($_POST['csrf'], $_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        http_response_code(403);
        die("Request blocked (CSRF check failed).");
    }
}

/* ---------- Flash messages (show once, then disappear) ---------- */
function set_flash($type, $text) {
    $_SESSION['flash'] = ['type' => $type, 'text' => $text];
}
function get_flash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/* ---------- WHO DID IT: save every important action ---------- */
function log_action($conn, $username, $action) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $conn->prepare("INSERT INTO audit_log (username, action, ip) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $action, $ip);
    $stmt->execute();
}

/* =========================================================
   PART 4: Password rules. Returns a list of problems.
   Empty list means the password is good.
   ========================================================= */
function password_problems($password, $username = "") {
    $problems = [];
    if (strlen($password) < 8)              $problems[] = "Use at least 8 characters.";
    if (!preg_match('/[A-Z]/', $password))  $problems[] = "Add an uppercase letter.";
    if (!preg_match('/[a-z]/', $password))  $problems[] = "Add a lowercase letter.";
    if (!preg_match('/[0-9]/', $password))  $problems[] = "Add a number.";

    if ($username !== "" && stripos($password, $username) !== false) {
        $problems[] = "Do not put your username in your password.";
    }
    $too_common = ['password1', 'password123', 'qwerty123', 'admin1234', 'welcome123', 'letmein123'];
    if (in_array(strtolower($password), $too_common, true)) {
        $problems[] = "That password is too common.";
    }
    return $problems;
}
